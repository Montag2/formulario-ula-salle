<?php
return [
  'DB_HOST' => '127.0.0.1',
  'DB_NAME' => 'u_lasalle',
  'DB_USER' => 'root',
  'DB_PASS' => '',
  'DB_PORT' => 3306,
];
