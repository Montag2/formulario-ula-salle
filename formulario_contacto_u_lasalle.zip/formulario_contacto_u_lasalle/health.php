<?php
header('Content-Type: text/plain; charset=utf-8');
echo "OK " . date('Y-m-d H:i:s');
